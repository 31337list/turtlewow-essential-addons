# Magnify

Magnify is a World of Warcraft (1.12) addon that rescales the world map frame and enables world map zoom.

The zoom feature is backported code from retail with several adjustments to make it work with the Vanilla client.